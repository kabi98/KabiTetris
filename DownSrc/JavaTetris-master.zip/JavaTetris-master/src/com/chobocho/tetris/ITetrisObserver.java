package com.chobocho.tetris;

import java.util.*;


public interface ITetrisObserver {
    public void update();
}