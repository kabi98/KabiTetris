package com.chobocho.tetris;

/**
 * Created by chobo on 2017-12-26.
 */

public class TetrisLog {
    public static void d(String log) {
        System.out.println("Tetris (d) " + log);
    }
    public static void e(String log) {
        System.out.println("Tetris (e)" + log);
    }
}
