package com.chobocho.player;

public interface IPlayerAction {
    public void onKeyEvent(int k);
    public void setPlayer(IPlayer player);
}
