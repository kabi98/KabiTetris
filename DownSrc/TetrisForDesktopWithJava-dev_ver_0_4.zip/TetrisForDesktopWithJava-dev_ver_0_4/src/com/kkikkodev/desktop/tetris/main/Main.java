package com.kkikkodev.desktop.tetris.main;

import com.kkikkodev.desktop.tetris.view.MainMenuPopup;

public class Main {

	public static void main(String[] args) {
		new MainMenuPopup().setVisible(true);
	}
}
