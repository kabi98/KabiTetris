package com.lemonapple.javatetris.model;

public interface ViewListener {
	public void onRePaint();
}
