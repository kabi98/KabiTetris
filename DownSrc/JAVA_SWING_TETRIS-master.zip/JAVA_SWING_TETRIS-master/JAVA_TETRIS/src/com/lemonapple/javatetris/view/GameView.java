package com.lemonapple.javatetris.view;

import javax.swing.JPanel;

public class GameView extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5160020013786214772L;

	public GameView() {
		super();
		this.setBounds(100, 100, 400, 600); // x,y는 파라미터로 옮길 예정.
		this.setLayout(null);
		
		// status bar
		
		// tetris board
		
		// hold
		
		// next
	}
}
