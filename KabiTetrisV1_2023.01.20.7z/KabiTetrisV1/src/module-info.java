/**
 * 
 */
/**
 * @author KabiHome
 *
 */
module KabiTetrisV1 {
	requires java.desktop;
	requires java.logging;		
}