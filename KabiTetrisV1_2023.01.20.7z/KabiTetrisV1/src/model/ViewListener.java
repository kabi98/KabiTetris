package model;

public interface ViewListener {
	public void onRePaint();
}
